#ifndef ARESTA_H

#define ARESTA_H

class Aresta {
public:
    Aresta(int v1, int v2);

    const int v1;
    const int v2;
};

#endif /* ARESTA_H */
